package com.jordi.SpringBootProjectJordi.services;

import java.util.Optional;

import com.jordi.SpringBootProjectJordi.models.Rol;
import com.jordi.SpringBootProjectJordi.models.RolNombre;

public interface RolService {
    Optional<Rol> obtenerPorNombre(RolNombre rolNombre);
}
