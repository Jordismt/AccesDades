package com.jordi.SpringBootProjectJordi.dto;

public class DireccionDTO {
    private String direccion;
    private float latitud;
    private float longitud;
    private int zoom;

    public DireccionDTO() {
    }

    public DireccionDTO(String direccion, float latitud, float longitud, int zoom) {
        this.direccion = direccion;
        this.latitud = latitud;
        this.longitud = longitud;
        this.zoom = zoom;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public float getLatitud() {
        return latitud;
    }

    public void setLatitud(float latitud) {
        this.latitud = latitud;
    }

    public float getLongitud() {
        return longitud;
    }

    public void setLongitud(float longitud) {
        this.longitud = longitud;
    }

    public int getZoom() {
        return zoom;
    }

    public void setZoom(int zoom) {
        this.zoom = zoom;
    }

    @Override
    public String toString() {
        return "DireccionDTO{" +
                "direccion='" + direccion + '\'' +
                ", latitud=" + latitud +
                ", longitud=" + longitud +
                ", zoom=" + zoom +
                '}';
    }
}
