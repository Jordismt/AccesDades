package com.jordi.SpringBootProjectJordi.dto;

public class ClienteDireccionDTO {
    private String calle;
    private String ciudad;

    public ClienteDireccionDTO() {
    }

    public ClienteDireccionDTO(String calle, String ciudad) {
        this.calle = calle;
        this.ciudad = ciudad;
    }

    public String getCalle() {
        return calle;
    }

    public void setCalle(String calle) {
        this.calle = calle;
    }

    public String getCiudad() {
        return ciudad;
    }

    public void setCiudad(String ciudad) {
        this.ciudad = ciudad;
    }

    @Override
    public String toString() {
        return "ClienteDireccionDTO{" +
                "calle='" + calle + '\'' +
                ", ciudad='" + ciudad + '\'' +
                '}';
    }
}
