package com.jordi.SpringBootProjectJordi.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.jordi.SpringBootProjectJordi.models.Cajero;

public interface CajeroRepository extends JpaRepository<Cajero, Long> {
}

