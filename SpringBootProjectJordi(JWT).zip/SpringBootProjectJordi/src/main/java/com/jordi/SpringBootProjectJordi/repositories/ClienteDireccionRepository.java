package com.jordi.SpringBootProjectJordi.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.jordi.SpringBootProjectJordi.models.ClienteDireccion;

public interface ClienteDireccionRepository extends JpaRepository<ClienteDireccion, Long> {
}

