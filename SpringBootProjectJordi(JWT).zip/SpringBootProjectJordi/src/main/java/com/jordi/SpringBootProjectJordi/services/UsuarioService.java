package com.jordi.SpringBootProjectJordi.services;

import java.util.Optional;

import com.jordi.SpringBootProjectJordi.models.Usuario;
import com.jordi.SpringBootProjectJordi.payloads.request.LoginRequest;

public interface UsuarioService {
    Usuario registrarUsuario(LoginRequest usuarioRequest);
    Optional<Usuario> obtenerPorUsername(String username);
}
