package com.jordi.SpringBootProjectJordi.services;

import java.util.List;

import com.jordi.SpringBootProjectJordi.dto.CajeroDTO;
import com.jordi.SpringBootProjectJordi.models.Cajero;

public interface CajeroService {
    
    // Obtener todos los cajeros
    List<Cajero> getAllCajeros();
    
    // Obtener un cajero por su ID
    Cajero getCajeroById(Long id);
    
    // Guardar un nuevo cajero a partir de un DTO
    Cajero saveCajero(CajeroDTO cajeroDTO);
    
    // Actualizar un cajero existente a partir de un DTO
    Cajero updateCajero(Long id, CajeroDTO cajeroDTO);
    
    // Eliminar un cajero por su ID
    void deleteCajero(Long id);
}

