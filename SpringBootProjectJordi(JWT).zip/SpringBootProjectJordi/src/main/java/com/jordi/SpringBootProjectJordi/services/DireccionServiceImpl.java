package com.jordi.SpringBootProjectJordi.services;

import com.jordi.SpringBootProjectJordi.dto.DireccionDTO;
import com.jordi.SpringBootProjectJordi.models.Direccion;
import com.jordi.SpringBootProjectJordi.repositories.DireccionRepository;

import jakarta.persistence.EntityNotFoundException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import java.util.List;

@Service
public class DireccionServiceImpl implements DireccionService {

    @Autowired
    private DireccionRepository direccionRepository;

    @Override
    public List<Direccion> getAllDirecciones() {
        return direccionRepository.findAll();
    }

    @Override
    public Direccion getDireccionById(int id) {
        return direccionRepository.findById((long) id).orElse(null);
    }

    @Override
    public Direccion saveDireccion(DireccionDTO direccionDTO) {
        Direccion direccion = convertirDTOaDireccion(direccionDTO);
        return direccionRepository.save(direccion);
    }

    @Override
    public Direccion updateDireccion(int id, DireccionDTO direccionDTO) {
        Direccion existingDireccion = direccionRepository.findById((long) id).orElse(null);

        if (existingDireccion != null) {
            existingDireccion.setDireccion(direccionDTO.getDireccion());
            // Actualiza otros campos según sea necesario

            return direccionRepository.save(existingDireccion);
        } else {
            // Manejo de error si la dirección no se encuentra
            throw new EntityNotFoundException("Dirección no encontrada con ID: " + id);
        }
    }

    @Override
    public void deleteDireccion(int id) {
        direccionRepository.deleteById((long) id);
    }

    private Direccion convertirDTOaDireccion(DireccionDTO direccionDTO) {
        Direccion direccion = new Direccion();
        direccion.setDireccion(direccionDTO.getDireccion());
        return direccion;
    }
}
