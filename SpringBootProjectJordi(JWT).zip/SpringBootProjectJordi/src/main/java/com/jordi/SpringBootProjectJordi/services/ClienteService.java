package com.jordi.SpringBootProjectJordi.services;

import java.util.List;

import com.jordi.SpringBootProjectJordi.dto.ClienteDTO;
import com.jordi.SpringBootProjectJordi.models.Cliente;

public interface ClienteService {
    List<Cliente> getAllClientes();
    Cliente getClienteById(int id);
    Cliente saveCliente(ClienteDTO clienteDTO);
    Cliente updateCliente(int id, ClienteDTO clienteDTO);
    void deleteCliente(int id);
}
