package com.jordi.SpringBootProjectJordi.controllers;


import com.jordi.SpringBootProjectJordi.payloads.request.LoginRequest;
import com.jordi.SpringBootProjectJordi.payloads.response.LoginResponse;
import com.jordi.SpringBootProjectJordi.security.jwt.JwtTokenProvider;
import com.jordi.SpringBootProjectJordi.services.UsuarioService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/auth")
public class AuthController {

    @Autowired
    private AuthenticationManager authenticationManager;

    @Autowired
    private JwtTokenProvider jwtTokenProvider;

    @Autowired
    private UsuarioService usuarioService;

    @PostMapping("/login")
    public ResponseEntity<LoginResponse> authenticateUser(@RequestBody LoginRequest loginRequest) {

        // Autenticar el usuario
        Authentication authentication = authenticationManager.authenticate(
                new UsernamePasswordAuthenticationToken(
                        loginRequest.getUsername(),
                        loginRequest.getPassword()
                )
        );

        // Establecer la autenticación en el contexto de seguridad
        SecurityContextHolder.getContext().setAuthentication(authentication);

        // Generar el token JWT
        String jwt = jwtTokenProvider.generateToken(authentication);

        // Crear el objeto LoginResponse con el token
        LoginResponse loginResponse = new LoginResponse(jwt);

        // Devolver el objeto LoginResponse en la respuesta
        return ResponseEntity.ok(loginResponse);
    }


}
