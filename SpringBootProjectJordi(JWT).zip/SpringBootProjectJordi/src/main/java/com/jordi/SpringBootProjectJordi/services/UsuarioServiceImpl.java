package com.jordi.SpringBootProjectJordi.services;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.jordi.SpringBootProjectJordi.models.Usuario;
import com.jordi.SpringBootProjectJordi.repositories.UsuarioRepository;

@Service
public class UsuarioServiceImpl implements UsuarioService {

    @Autowired
    private UsuarioRepository usuarioRepository;

    @Autowired
    private RolService rolService;

    @Override
    public Usuario registrarUsuario(UsuarioRequest usuarioRequest) {
        // Implementa la lógica para registrar un nuevo usuario
    }

    @Override
    public Optional<Usuario> obtenerPorUsername(String username) {
        return usuarioRepository.findByUsername(username);
    }
}
