package com.jordi.SpringBootProjectJordi.config;

import com.jordi.SpringBootProjectJordi.security.jwt.JwtConfigurer;
import com.jordi.SpringBootProjectJordi.security.jwt.JwtTokenProvider;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;

@Configuration
@EnableWebSecurity
public class SecurityConfig extends WebSecurityConfigurerAdapter {

    @Autowired
    private JwtTokenProvider jwtTokenProvider;

    @Override
    protected void configure(HttpSecurity http) throws Exception {
        // Configuración para permitir el acceso público a algunas rutas
        http
            .authorizeRequests()
                .antMatchers("/api/public").permitAll()
                .antMatchers("/api/auth/**").authenticated()
                .and()
            .apply(new JwtConfigurer(jwtTokenProvider));
    }
}
