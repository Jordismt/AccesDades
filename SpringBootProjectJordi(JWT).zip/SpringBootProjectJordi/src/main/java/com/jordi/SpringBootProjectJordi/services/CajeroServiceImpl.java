package com.jordi.SpringBootProjectJordi.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.jordi.SpringBootProjectJordi.dto.CajeroDTO;
import com.jordi.SpringBootProjectJordi.models.Cajero;
import com.jordi.SpringBootProjectJordi.repositories.CajeroRepository;

import jakarta.persistence.EntityNotFoundException;

import java.util.List;

@Service
public class CajeroServiceImpl implements CajeroService {

    @Autowired
    private CajeroRepository cajeroRepository;

    @Override
    public List<Cajero> getAllCajeros() {
        return cajeroRepository.findAll();
    }

    @Override
    public Cajero getCajeroById(Long id) {
        return cajeroRepository.findById(id).orElse(null);
    }

    @Override
    public Cajero saveCajero(CajeroDTO cajeroDTO) {
        // Implementa la conversión de CajeroDTO a Cajero
        Cajero cajero = convertirDTOaCajero(cajeroDTO);
        return cajeroRepository.save(cajero);
    }

    @Override
    public Cajero updateCajero(Long id, CajeroDTO cajeroDTO) {
        // Implementa la lógica de actualización aquí
        Cajero existingCajero = cajeroRepository.findById(id).orElse(null);

        if (existingCajero != null) {
            // Actualiza los campos del Cajero existente con los nuevos valores proporcionados
            existingCajero.setDireccion(cajeroDTO.getDireccion());
            existingCajero.setLatitud(cajeroDTO.getLatitud());
            existingCajero.setLongitud(cajeroDTO.getLongitud());
            existingCajero.setZoom(cajeroDTO.getZoom());

            // Guarda el Cajero actualizado en la base de datos
            return cajeroRepository.save(existingCajero);
        } else {
            // Manejo de error si el Cajero no se encuentra
            throw new EntityNotFoundException("Cajero no encontrado con ID: " + id);
        }
    }

    @Override
    public void deleteCajero(Long id) {
        cajeroRepository.deleteById(id);
    }

    // Método de conversión de DTO a Cajero (deberías implementar tu propia lógica aquí)
    private Cajero convertirDTOaCajero(CajeroDTO cajeroDTO) {
        Cajero cajero = new Cajero();
        // Asigna los valores del DTO al Cajero
        cajero.setDireccion(cajeroDTO.getDireccion());
        cajero.setLatitud(cajeroDTO.getLatitud());
        cajero.setLongitud(cajeroDTO.getLongitud());
        cajero.setZoom(cajeroDTO.getZoom());
        return cajero;
    }

}
