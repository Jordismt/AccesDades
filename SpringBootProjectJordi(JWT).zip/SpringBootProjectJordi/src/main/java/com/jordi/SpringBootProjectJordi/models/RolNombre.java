package com.jordi.SpringBootProjectJordi.models;

public enum RolNombre {
    ROLE_USER,
    ROLE_MODERATOR,
    ROLE_ADMIN
}
