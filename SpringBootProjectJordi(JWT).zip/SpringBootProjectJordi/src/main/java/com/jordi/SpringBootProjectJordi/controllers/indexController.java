package com.jordi.SpringBootProjectJordi.controllers;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.beans.factory.annotation.Value;


@RestController
@RequestMapping("/")
public class indexController {

    @Value("${app.name}")
    private String appName;

    @Value("${developer.name}")
    private String devName;

    @GetMapping()
    public String about() {
    	return "<html>" +
        		"<head>" +
                "<style>" +
                "  body {" +
                "    font-family: Arial, sans-serif;" +
                "    background-color: #f4f4f4;" +
                "    margin: 20px;" +
                "    text-align: center;" + 
                "  }" +
                "  h1 {" +
                "    color: #333333;" +
                "	 opacity: 0;"+
                "	 animation: slideIn 1s forwards; "+
                "  }" +
                "@keyframes slideIn {"+   
                "	from {"+
                "		opacity: 0;"+
                "		transform: translateY(100%);"+
                "	}"+
                "	to{"+
                "		opacity: 1;"+
                "		transform: translateY(0);"+
                "	}"+
                "}"+
                "  h3 {" +
                "    color: #666666;" +
                "  }" +
                "  p {" +
                "    color: #888888;" +
                "  }" +
                "  a {" +
                "    color: #007bff;" +
                "    text-decoration: none;" +
                "    border: 1px solid #007bff;" +
                "    padding: 5px 10px;" +
                "    border-radius: 5px;" +
                "    display: inline-block;" +
                "    margin-top: 10px;" +
                "  }" +
                "  a:hover{"+
                "    background-color: black;"+
                "    color: white;"+
                "  .fin {" +
                "    margin-top: auto;" +
                "    text-align: center;" + 
                "  }" +
                "</style>" +
                "</head>" +
                "<body>" +
                "<h1>" + appName + "</h1>" +
                "<h3>Made by " + devName +" 2DAM </h3>" +
                "<p>Este es un proyecto del módulo de Acceso a Datos.</p>"+
                "<br><br><hr><br>"+
                "<h4>MENU:</h4>"+
                "<br><br>"+
                "<a href=\"/api/cajeros\">Ver todos los Cajeros</a>" +
                "</br>"+
                "</br>"+
                "<a href=\"/api/clientes\">Ver todos los Clientes</a>" +
                "</br>"+
                "</br>"+
                "<a href=\"/api/direcciones\">Ver todas las Direcciones</a>" +
                "</br>"+
                "</br>"+
                "<a href=\"/api/clienteDirecciones\">Ver todas las ClientesDirecciones</a>" +
                "<br><br><br><br><hr><br><br><br><br>"+
                "<p class='fin'>Gracias por visitar esta pagina, espero verte pronto!</p>"+
                "</body>" +
                "</html>";
    }
    
}

