package com.jordi.SpringBootProjectJordi.models;


import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity(name = "clientes")
public class Cliente {
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String nif;
    private String nombre;
    private String apellidos;
    private String claveseguridad;
    private String email;
    
    //Getter setter constructor
    
    
	public Cliente(Long id, String nif, String nombre, String apellidos, String claveseguridad, String email) {
		super();
		this.id = id;
		this.nif = nif;
		this.nombre = nombre;
		this.apellidos = apellidos;
		this.claveseguridad = claveseguridad;
		this.email = email;
	}
	
	public Cliente() {
		super();
	}

	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getNif() {
		return nif;
	}
	public void setNif(String nif) {
		this.nif = nif;
	}
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public String getApellidos() {
		return apellidos;
	}
	public void setApellidos(String apellidos) {
		this.apellidos = apellidos;
	}
	public String getClaveseguridad() {
		return claveseguridad;
	}
	public void setClaveseguridad(String claveseguridad) {
		this.claveseguridad = claveseguridad;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
    

    
    
}
