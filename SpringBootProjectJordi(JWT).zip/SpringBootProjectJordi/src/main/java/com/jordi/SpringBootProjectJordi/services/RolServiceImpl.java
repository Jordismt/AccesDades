package com.jordi.SpringBootProjectJordi.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.jordi.SpringBootProjectJordi.repositories.RolRepository;

@Service
public class RolServiceImpl implements RolService {

    @Autowired
    private RolRepository rolRepository;

    @Override
    public Optional<Rol> obtenerPorNombre(RolNombre rolNombre) {
        return rolRepository.findByNombre(rolNombre);
    }
}