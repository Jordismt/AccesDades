package com.jordi.SpringBootProjectJordi.dto;

import lombok.Data;

@Data
public class CajeroDTO {
    private String direccion;
    private float latitud;
    private float longitud;
    private int zoom;
}
