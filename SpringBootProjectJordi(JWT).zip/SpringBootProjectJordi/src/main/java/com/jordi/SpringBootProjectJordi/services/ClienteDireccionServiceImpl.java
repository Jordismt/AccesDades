package com.jordi.SpringBootProjectJordi.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.jordi.SpringBootProjectJordi.dto.ClienteDireccionDTO;

import com.jordi.SpringBootProjectJordi.models.ClienteDireccion;
import com.jordi.SpringBootProjectJordi.models.Direccion;
import com.jordi.SpringBootProjectJordi.repositories.ClienteDireccionRepository;
import com.jordi.SpringBootProjectJordi.repositories.DireccionRepository;



import java.util.List;

@Service
public class ClienteDireccionServiceImpl implements ClienteDireccionService {

    @Autowired
    private ClienteDireccionRepository clienteDireccionRepository;

    @Autowired
    private DireccionRepository direccionRepository;

    @Override
    public List<ClienteDireccion> getAllClienteDirecciones() {
        return clienteDireccionRepository.findAll();
    }

    @Override
    @Transactional
    public ClienteDireccion saveClienteDireccion(ClienteDireccionDTO clienteDireccionDTO) {
        ClienteDireccion clienteDireccion = convertirDTOaClienteDireccion(clienteDireccionDTO);
        return clienteDireccionRepository.save(clienteDireccion);
    }

    @Override
    public void deleteClienteDireccion(Long id) {
        clienteDireccionRepository.deleteById(id);
    }

    private ClienteDireccion convertirDTOaClienteDireccion(ClienteDireccionDTO clienteDireccionDTO) {
        ClienteDireccion clienteDireccion = new ClienteDireccion();

        // Obtener la dirección existente o guardar una nueva si no existe
        Direccion direccion = direccionRepository.findByDireccion(clienteDireccionDTO.getCalle());
        if (direccion == null) {
            direccion = new Direccion(clienteDireccionDTO.getCalle(), clienteDireccionDTO.getCiudad());
            direccion = direccionRepository.save(direccion);
        }

        clienteDireccion.setDireccion(direccion);
        // Asigna otros campos según sea necesario
        return clienteDireccion;
    }
}
