package com.jordi.SpringBootProjectJordi.controllers;

import com.jordi.SpringBootProjectJordi.dto.DireccionDTO;
import com.jordi.SpringBootProjectJordi.models.Direccion;
import com.jordi.SpringBootProjectJordi.services.DireccionService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/direcciones")
public class DireccionController {

    @Autowired
    private DireccionService direccionService;

    @GetMapping
    public List<Direccion> getAllDirecciones() {
        return direccionService.getAllDirecciones();
    }

    @GetMapping("/{id}")
    public ResponseEntity<Direccion> getDireccionById(@PathVariable int id) {
        Direccion direccion = direccionService.getDireccionById(id);
        if (direccion != null) {
            return ResponseEntity.ok(direccion);
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    @PostMapping
    public ResponseEntity<Direccion> saveDireccion(@RequestBody DireccionDTO direccionDTO) {
        Direccion direccion = direccionService.saveDireccion(direccionDTO);
        return ResponseEntity.ok(direccion);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Direccion> updateDireccion(@PathVariable int id, @RequestBody DireccionDTO direccionDTO) {
        Direccion updatedDireccion = direccionService.updateDireccion(id, direccionDTO);
        if (updatedDireccion != null) {
            return ResponseEntity.ok(updatedDireccion);
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteDireccion(@PathVariable int id) {
        direccionService.deleteDireccion(id);
        return ResponseEntity.noContent().build();
    }
}
