package com.jordi.SpringBootProjectJordi.repositories;

import com.jordi.SpringBootProjectJordi.models.Direccion;
import org.springframework.data.jpa.repository.JpaRepository;

public interface DireccionRepository extends JpaRepository<Direccion, Long> {
    Direccion findByDireccion(String direccion);
}
