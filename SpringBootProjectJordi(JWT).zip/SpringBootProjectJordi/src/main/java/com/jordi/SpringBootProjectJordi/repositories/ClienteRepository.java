package com.jordi.SpringBootProjectJordi.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.jordi.SpringBootProjectJordi.models.Cliente;

public interface ClienteRepository extends JpaRepository<Cliente, Long> {
}

