package com.jordi.SpringBootProjectJordi.services;

import java.util.List;

import com.jordi.SpringBootProjectJordi.dto.ClienteDireccionDTO;
import com.jordi.SpringBootProjectJordi.models.ClienteDireccion;

public interface ClienteDireccionService {
    List<ClienteDireccion> getAllClienteDirecciones();
    ClienteDireccion saveClienteDireccion(ClienteDireccionDTO clienteDireccionDTO);
    void deleteClienteDireccion(Long id);
}
