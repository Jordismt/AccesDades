package com.jordi.SpringBootProjectJordi.controllers;

import com.jordi.SpringBootProjectJordi.dto.ClienteDireccionDTO;
import com.jordi.SpringBootProjectJordi.models.ClienteDireccion;
import com.jordi.SpringBootProjectJordi.services.ClienteDireccionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/clienteDirecciones")
public class ClienteDireccionController {

    @Autowired
    private ClienteDireccionService clienteDireccionService;

    @GetMapping
    public List<ClienteDireccion> getAllClienteDirecciones() {
        return clienteDireccionService.getAllClienteDirecciones();
    }

    @PostMapping
    public ResponseEntity<ClienteDireccion> saveClienteDireccion(@RequestBody ClienteDireccionDTO clienteDireccionDTO) {
        ClienteDireccion clienteDireccion = clienteDireccionService.saveClienteDireccion(clienteDireccionDTO);
        return ResponseEntity.ok(clienteDireccion);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteClienteDireccion(@PathVariable Long id) {
        clienteDireccionService.deleteClienteDireccion(id);
        return ResponseEntity.noContent().build();
    }
}
