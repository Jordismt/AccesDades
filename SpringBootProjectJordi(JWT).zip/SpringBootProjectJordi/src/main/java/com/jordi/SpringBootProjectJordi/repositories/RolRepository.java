package com.jordi.SpringBootProjectJordi.repositories;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.jordi.SpringBootProjectJordi.models.Rol;
import com.jordi.SpringBootProjectJordi.models.RolNombre;

public interface RolRepository extends JpaRepository<Rol, Long> {
    Optional<Rol> findByNombre(RolNombre rolNombre);
}
