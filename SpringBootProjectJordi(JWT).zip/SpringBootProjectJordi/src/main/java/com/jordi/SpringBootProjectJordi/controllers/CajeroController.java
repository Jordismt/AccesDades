package com.jordi.SpringBootProjectJordi.controllers;

import org.springframework.web.bind.annotation.*;

import com.jordi.SpringBootProjectJordi.dto.CajeroDTO;
import com.jordi.SpringBootProjectJordi.models.Cajero;
import com.jordi.SpringBootProjectJordi.services.CajeroService;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;


@RestController
@RequestMapping("/api/cajeros")
public class CajeroController {

    @Autowired
    private CajeroService cajeroService;

    @GetMapping
    public List<Cajero> getAllCajeros() {
        return cajeroService.getAllCajeros();
    }

    @GetMapping("/{id}")
    public Cajero getCajeroById(@PathVariable Long id) {
        return cajeroService.getCajeroById(id);
    }

    @PostMapping
    public Cajero saveCajero(@RequestBody CajeroDTO cajeroDTO) {
        return cajeroService.saveCajero(cajeroDTO);
    }

    @PutMapping("/{id}")
    public Cajero updateCajero(@PathVariable Long id, @RequestBody CajeroDTO cajeroDTO) {
        return cajeroService.updateCajero(id, cajeroDTO);
    }

    @DeleteMapping("/{id}")
    public void deleteCajero(@PathVariable Long id) {
        cajeroService.deleteCajero(id);
    }
}
