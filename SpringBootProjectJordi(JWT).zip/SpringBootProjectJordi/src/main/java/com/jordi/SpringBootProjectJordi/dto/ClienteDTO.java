package com.jordi.SpringBootProjectJordi.dto;

import lombok.Data;

@Data
public class ClienteDTO {
    private String nif;
    private String nombre;
    private String apellidos;
    private String claveseguridad;
    private String email;
}

