package com.jordi.SpringBootProjectJordi.services;

import java.util.List;

import com.jordi.SpringBootProjectJordi.dto.DireccionDTO;
import com.jordi.SpringBootProjectJordi.models.Direccion;

public interface DireccionService {
    List<Direccion> getAllDirecciones();
    Direccion getDireccionById(int id);
    Direccion saveDireccion(DireccionDTO direccionDTO);
    Direccion updateDireccion(int id, DireccionDTO direccionDTO);
    void deleteDireccion(int id);
}
