package com.jordi.SpringBootProjectJordi.payloads.response;

import java.util.List;

public class JwtResponse {
	
	private String token;
	private String type="Bearer";
	private Long id;
	private String username;
	private List<String> roles;
}
