package com.jordi.SpringBootProjectJordi.controllers;

import org.springframework.web.bind.annotation.*;

import com.jordi.SpringBootProjectJordi.dto.ClienteDTO;
import com.jordi.SpringBootProjectJordi.models.Cliente;
import com.jordi.SpringBootProjectJordi.services.ClienteService;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;


@RestController
@RequestMapping("/api/clientes")
public class ClienteController {

    @Autowired
    private ClienteService clienteService;

    @GetMapping
    public List<Cliente> getAllClientes() {
        return clienteService.getAllClientes();
    }

    @GetMapping("/{id}")
    public Cliente getClienteById(@PathVariable int id) {
        return clienteService.getClienteById(id);
    }

    @PostMapping
    public Cliente saveCliente(@RequestBody ClienteDTO clienteDTO) {
        return clienteService.saveCliente(clienteDTO);
    }

    @PutMapping("/{id}")
    public Cliente updateCliente(@PathVariable Long id, @RequestBody ClienteDTO clienteDTO) {
        // Implementa la actualización (Modificar) según tus necesidades
        return null;
    }

    @DeleteMapping("/{id}")
    public void deleteCliente(@PathVariable int id) {
        clienteService.deleteCliente(id);
    }
}
