package com.jordi.SpringBootProjectJordi.services;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.jordi.SpringBootProjectJordi.dto.ClienteDTO;
import com.jordi.SpringBootProjectJordi.models.Cliente;
import com.jordi.SpringBootProjectJordi.repositories.ClienteRepository;

import jakarta.persistence.EntityNotFoundException;

import java.util.List;

@Service
public class ClienteServiceImpl implements ClienteService {

    @Autowired
    private ClienteRepository clienteRepository;

    @Override
    public List<Cliente> getAllClientes() {
        return clienteRepository.findAll();
    }

    @Override
    public Cliente getClienteById(int id) {
        return clienteRepository.findById((long) id).orElse(null);
    }

    @Override
    public Cliente saveCliente(ClienteDTO clienteDTO) {
        Cliente cliente = convertirDTOaCliente(clienteDTO);
        return clienteRepository.save(cliente);
    }

    @Override
    public Cliente updateCliente(int id, ClienteDTO clienteDTO) {
        Cliente existingCliente = clienteRepository.findById((long) id).orElse(null);

        if (existingCliente != null) {
            existingCliente.setNombre(clienteDTO.getNombre());
            existingCliente.setApellidos(clienteDTO.getApellidos());
            existingCliente.setEmail(clienteDTO.getEmail());
            

            return clienteRepository.save(existingCliente);
        } else {
            // Manejo de error si el cliente no se encuentra
            throw new EntityNotFoundException("Cliente no encontrado con ID: " + id);
        }
    }

    @Override
    public void deleteCliente(int id) {
        clienteRepository.deleteById((long) id);
    }

    private Cliente convertirDTOaCliente(ClienteDTO clienteDTO) {
        Cliente cliente = new Cliente();
        cliente.setNombre(clienteDTO.getNombre());
        cliente.setApellidos(clienteDTO.getApellidos());
        cliente.setEmail(clienteDTO.getEmail());
        // Asigna otros campos según sea necesario
        return cliente;
    }
}
